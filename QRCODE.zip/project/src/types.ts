export interface QRCodeSettings {
  size: number;
  fgColor: string;
  bgColor: string;
  level: string;
  includeMargin: boolean;
}

export interface HistoryItem {
  id: string;
  value: string;
  settings: QRCodeSettings;
  timestamp: string;
}