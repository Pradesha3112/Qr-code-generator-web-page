import React, { useState, useEffect } from 'react';
import InputForm from './InputForm';
import QRCodeDisplay from './QRCodeDisplay';
import HistoryPanel from './HistoryPanel';
import { QRCodeSettings, HistoryItem } from '../types';

const QRCodeGenerator: React.FC = () => {
  const [qrValue, setQrValue] = useState<string>('');
  const [qrSettings, setQrSettings] = useState<QRCodeSettings>({
    size: 200,
    fgColor: '#000000',
    bgColor: '#FFFFFF',
    level: 'L',
    includeMargin: true,
  });
  const [history, setHistory] = useState<HistoryItem[]>([]);
  
  // Load history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('qrCodeHistory');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error('Failed to parse history from localStorage:', e);
      }
    }
  }, []);
  
  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('qrCodeHistory', JSON.stringify(history));
  }, [history]);
  
  const handleGenerate = (value: string, settings: QRCodeSettings) => {
    setQrValue(value);
    setQrSettings(settings);
    
    // Add to history
    if (value.trim()) {
      const newItem: HistoryItem = {
        id: Date.now().toString(),
        value,
        settings,
        timestamp: new Date().toISOString(),
      };
      
      setHistory(prev => {
        // Keep only the last 10 items
        const updatedHistory = [newItem, ...prev.filter(item => item.value !== value)].slice(0, 10);
        return updatedHistory;
      });
    }
  };
  
  const handleHistoryItemClick = (item: HistoryItem) => {
    setQrValue(item.value);
    setQrSettings(item.settings);
  };
  
  return (
    <div className="w-full max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 bg-white rounded-xl shadow-md p-6 transform transition-all duration-300 hover:shadow-lg">
          <InputForm
            onGenerate={handleGenerate}
            initialValue={qrValue}
            initialSettings={qrSettings}
          />
        </div>
        <div className="lg:col-span-2 flex flex-col gap-6">
          <QRCodeDisplay
            value={qrValue}
            settings={qrSettings}
          />
          <HistoryPanel
            history={history}
            onItemClick={handleHistoryItemClick}
          />
        </div>
      </div>
    </div>
  );
};

export default QRCodeGenerator;