import React from 'react';
import { HistoryItem } from '../types';
import { Clock, X } from 'lucide-react';

interface HistoryPanelProps {
  history: HistoryItem[];
  onItemClick: (item: HistoryItem) => void;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onItemClick }) => {
  if (history.length === 0) {
    return null;
  }
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  // Truncate long strings for display
  const truncate = (str: string, length = 25) => {
    if (str.length <= length) return str;
    return str.substring(0, length) + '...';
  };
  
  return (
    <div className="bg-white/70 backdrop-blur-md rounded-xl shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-800 flex items-center">
          <Clock className="h-4 w-4 mr-2 text-gray-600" />
          Recent History
        </h2>
      </div>
      
      <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
        {history.map((item) => (
          <div
            key={item.id}
            onClick={() => onItemClick(item)}
            className="p-3 rounded-md bg-gray-50 hover:bg-gray-100 cursor-pointer transition-colors duration-200 flex items-center justify-between"
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {truncate(item.value)}
              </p>
              <p className="text-xs text-gray-500">
                {formatDate(item.timestamp)}
              </p>
            </div>
            <div 
              className="ml-2 w-6 h-6 rounded-full"
              style={{ 
                backgroundColor: item.settings.fgColor,
                border: `1px solid ${item.settings.bgColor === '#FFFFFF' ? '#E5E7EB' : item.settings.bgColor}`
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoryPanel;