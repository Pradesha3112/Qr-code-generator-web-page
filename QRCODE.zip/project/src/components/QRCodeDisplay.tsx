import React, { useRef } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { QRCodeSettings } from '../types';
import { Download, Copy, AlertCircle } from 'lucide-react';

interface QRCodeDisplayProps {
  value: string;
  settings: QRCodeSettings;
}

const QRCodeDisplay: React.FC<QRCodeDisplayProps> = ({ value, settings }) => {
  const qrRef = useRef<HTMLDivElement>(null);
  
  const downloadQRCode = () => {
    if (!qrRef.current) return;
    
    const canvas = qrRef.current.querySelector('canvas');
    if (!canvas) return;
    
    const link = document.createElement('a');
    link.download = `qrcode-${new Date().toISOString().split('T')[0]}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };
  
  const copyToClipboard = async () => {
    if (!qrRef.current) return;
    
    const canvas = qrRef.current.querySelector('canvas');
    if (!canvas) return;
    
    try {
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
        }, 'image/png');
      });
      
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]);
      
      // You could add a toast notification here
    } catch (err) {
      console.error('Failed to copy QR code: ', err);
    }
  };
  
  return (
    <div className="bg-white/70 backdrop-blur-md rounded-xl shadow-md p-6 flex flex-col items-center">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Your QR Code</h2>
      
      <div 
        ref={qrRef}
        className="p-4 bg-white rounded-lg shadow-sm flex items-center justify-center mb-4 transition-all duration-300 hover:shadow-md"
        style={{ minHeight: `${settings.size + 40}px`, minWidth: `${settings.size + 40}px` }}
      >
        {value ? (
          <QRCodeCanvas
            value={value}
            size={settings.size}
            bgColor={settings.bgColor}
            fgColor={settings.fgColor}
            level={settings.level as 'L' | 'M' | 'Q' | 'H'}
            includeMargin={settings.includeMargin}
            className="transition-all duration-300"
          />
        ) : (
          <div className="text-center p-6 text-gray-500 flex flex-col items-center">
            <AlertCircle className="h-12 w-12 mb-2 text-gray-400" />
            <p>Enter some text to generate a QR code</p>
          </div>
        )}
      </div>
      
      <div className="flex space-x-3 w-full">
        <button
          onClick={downloadQRCode}
          disabled={!value}
          className={`flex-1 flex items-center justify-center py-2 px-4 rounded-md text-white font-medium transition-all ${
            value 
              ? 'bg-blue-600 hover:bg-blue-700' 
              : 'bg-gray-300 cursor-not-allowed'
          }`}
        >
          <Download className="h-4 w-4 mr-2" />
          Download
        </button>
        
        <button
          onClick={copyToClipboard}
          disabled={!value}
          className={`flex-1 flex items-center justify-center py-2 px-4 rounded-md font-medium transition-all ${
            value 
              ? 'bg-gray-100 text-gray-800 hover:bg-gray-200' 
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          }`}
        >
          <Copy className="h-4 w-4 mr-2" />
          Copy
        </button>
      </div>
    </div>
  );
};

export default QRCodeDisplay;