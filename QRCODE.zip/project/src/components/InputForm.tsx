import React, { useState, useEffect } from 'react';
import { QRCodeSettings } from '../types';
import { InfoIcon, Link2, AtSign, Type } from 'lucide-react';

interface InputFormProps {
  onGenerate: (value: string, settings: QRCodeSettings) => void;
  initialValue: string;
  initialSettings: QRCodeSettings;
}

const InputForm: React.FC<InputFormProps> = ({ 
  onGenerate, 
  initialValue, 
  initialSettings 
}) => {
  const [text, setText] = useState(initialValue);
  const [inputType, setInputType] = useState<'text' | 'url' | 'email'>('text');
  const [settings, setSettings] = useState<QRCodeSettings>(initialSettings);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  useEffect(() => {
    setText(initialValue);
  }, [initialValue]);
  
  useEffect(() => {
    setSettings(initialSettings);
  }, [initialSettings]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(text, settings);
  };
  
  const handleInputTypeChange = (type: 'text' | 'url' | 'email') => {
    setInputType(type);
    // Clear the input if changing type
    if (text) {
      setText('');
    }
  };
  
  const handleSettingChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    
    // Handle checkboxes
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setSettings((prev) => ({
        ...prev,
        [name]: checked,
      }));
      return;
    }
    
    // Handle number inputs
    if (type === 'number') {
      const numValue = parseInt(value, 10);
      setSettings((prev) => ({
        ...prev,
        [name]: numValue,
      }));
      return;
    }
    
    // Handle other inputs
    setSettings((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Helper function to get input label and placeholder based on input type
  const getInputDetails = () => {
    switch (inputType) {
      case 'url':
        return { 
          label: 'Enter URL', 
          placeholder: 'https://example.com',
          icon: <Link2 className="h-5 w-5 text-gray-400" />
        };
      case 'email':
        return { 
          label: 'Enter Email', 
          placeholder: 'example@email.com',
          icon: <AtSign className="h-5 w-5 text-gray-400" />
        };
      default:
        return { 
          label: 'Enter Text', 
          placeholder: 'Your text here',
          icon: <Type className="h-5 w-5 text-gray-400" />
        };
    }
  };
  
  const { label, placeholder, icon } = getInputDetails();
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">Create QR Code</h2>
        
        {/* Input Type Selection */}
        <div className="flex space-x-4 mb-4">
          <button
            type="button"
            className={`px-4 py-2 rounded-md transition-all ${
              inputType === 'text'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => handleInputTypeChange('text')}
          >
            Text
          </button>
          <button
            type="button"
            className={`px-4 py-2 rounded-md transition-all ${
              inputType === 'url'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => handleInputTypeChange('url')}
          >
            URL
          </button>
          <button
            type="button"
            className={`px-4 py-2 rounded-md transition-all ${
              inputType === 'email'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => handleInputTypeChange('email')}
          >
            Email
          </button>
        </div>
        
        {/* Input Field */}
        <div className="space-y-2">
          <label htmlFor="qr-input" className="block text-sm font-medium text-gray-700">
            {label}
          </label>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              {icon}
            </div>
            <input
              type={inputType === 'email' ? 'email' : 'text'}
              id="qr-input"
              className="block w-full pl-10 pr-12 py-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              placeholder={placeholder}
              value={text}
              onChange={(e) => setText(e.target.value)}
              required
            />
          </div>
        </div>
        
        {/* Advanced Options Toggle */}
        <button
          type="button"
          className="flex items-center text-sm text-blue-600 hover:text-blue-800 transition-colors"
          onClick={() => setShowAdvanced(!showAdvanced)}
        >
          <span>{showAdvanced ? 'Hide' : 'Show'} Advanced Options</span>
          <InfoIcon className="h-4 w-4 ml-1" />
        </button>
        
        {/* Advanced Options */}
        {showAdvanced && (
          <div className="p-4 bg-gray-50 rounded-md space-y-4 animate-fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* QR Code Size */}
              <div>
                <label htmlFor="size" className="block text-sm font-medium text-gray-700">
                  Size (px)
                </label>
                <input
                  type="range"
                  id="size"
                  name="size"
                  min="100"
                  max="400"
                  step="10"
                  value={settings.size}
                  onChange={handleSettingChange}
                  className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer"
                />
                <div className="text-center text-sm text-gray-600">
                  {settings.size}px
                </div>
              </div>
              
              {/* Error Correction Level */}
              <div>
                <label htmlFor="level" className="block text-sm font-medium text-gray-700">
                  Error Correction
                </label>
                <select
                  id="level"
                  name="level"
                  value={settings.level}
                  onChange={handleSettingChange}
                  className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="L">Low (7%)</option>
                  <option value="M">Medium (15%)</option>
                  <option value="Q">Quartile (25%)</option>
                  <option value="H">High (30%)</option>
                </select>
              </div>
              
              {/* Foreground Color */}
              <div>
                <label htmlFor="fgColor" className="block text-sm font-medium text-gray-700">
                  Foreground Color
                </label>
                <div className="flex items-center mt-1">
                  <input
                    type="color"
                    id="fgColor"
                    name="fgColor"
                    value={settings.fgColor}
                    onChange={handleSettingChange}
                    className="h-8 w-8 border border-gray-300 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={settings.fgColor}
                    onChange={handleSettingChange}
                    name="fgColor"
                    className="ml-2 py-1 px-2 border border-gray-300 rounded-md text-sm w-24"
                  />
                </div>
              </div>
              
              {/* Background Color */}
              <div>
                <label htmlFor="bgColor" className="block text-sm font-medium text-gray-700">
                  Background Color
                </label>
                <div className="flex items-center mt-1">
                  <input
                    type="color"
                    id="bgColor"
                    name="bgColor"
                    value={settings.bgColor}
                    onChange={handleSettingChange}
                    className="h-8 w-8 border border-gray-300 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={settings.bgColor}
                    onChange={handleSettingChange}
                    name="bgColor"
                    className="ml-2 py-1 px-2 border border-gray-300 rounded-md text-sm w-24"
                  />
                </div>
              </div>
              
              {/* Include Margin */}
              <div className="col-span-2">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="includeMargin"
                    name="includeMargin"
                    checked={settings.includeMargin}
                    onChange={handleSettingChange}
                    className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <label htmlFor="includeMargin" className="ml-2 block text-sm text-gray-700">
                    Include margin around QR code
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div>
        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium py-3 px-4 rounded-md transition-all duration-200 transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Generate QR Code
        </button>
      </div>
    </form>
  );
};

export default InputForm;