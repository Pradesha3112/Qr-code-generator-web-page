import React from 'react';
import { QrCode } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm py-4">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <QrCode className="h-8 w-8 text-blue-600" />
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">QR Code Generator</h1>
        </div>
        <nav>
          <ul className="flex space-x-6">
            <li className="text-gray-600 hover:text-blue-600 transition-colors duration-200">
              <a href="#" className="flex items-center">
                <span>Home</span>
              </a>
            </li>
            <li className="text-gray-600 hover:text-blue-600 transition-colors duration-200">
              <a href="#" className="flex items-center">
                <span>About</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;